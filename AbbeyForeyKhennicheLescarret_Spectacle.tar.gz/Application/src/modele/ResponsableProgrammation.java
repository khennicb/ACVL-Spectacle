package modele;

public class ResponsableProgrammation extends Utilisateur{

	public ResponsableProgrammation(String login, String password) {
		super(login, password);
	}
}