package modele;

public class SuperUser extends Utilisateur{
	//singleton ???

	public SuperUser(String login, String password) {
		super(login, password);
	}
}