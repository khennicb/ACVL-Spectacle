package vue.Header;

import vue.*;

public class PanelHeader extends AbstractPanel {
	
	public PanelHeader () {
		super();
	}
	
}
